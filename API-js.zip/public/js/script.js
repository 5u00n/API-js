

function signIn(){
    var userEmail= document.getElementById("email").value;
    var pass=document.getElementById("pass").value;

}

/* 
Methods to send objects to API
*/

